using AWS_Exportel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AWS_S3.Controllers;

[AllowAnonymous]
[ApiController]
[Route("api/ExportBucket")]
public class ExportBucketController: ControllerBase
{
    private readonly IDocumentExporterManager _documentExporterManager;

    public ExportBucketController(IDocumentExporterManager documentExporterManager)
    {
        _documentExporterManager = documentExporterManager;
    }

    [HttpGet("/List")]
    public async Task<IActionResult> ExportBucket()
    {
        var result = await _documentExporterManager.GetExportBucket();
        return Ok(result);
    }
    [HttpGet("/Download")]
    public async Task<IActionResult> DownloadFile([FromQuery]string objectKey)
    {
        var result = await _documentExporterManager.DownloadFile(objectKey);
        return File(result, "application/octet-stream");
    }
}