using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AWS_Exportel;
using AWS_Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;

namespace AWS_Web.Controllers;

[AllowAnonymous]
[ApiController]
[Route("api/ExportBucket")]
public class ExportBucketController: ControllerBase
{
    private readonly IDocumentExporterManager _documentExporterManager;
    private readonly MemoryCache? _memoryCache;
    private readonly string MemoryCacheKey = "ExportBucket";
    public ExportBucketController(IDocumentExporterManager documentExporterManager
        ,MemoryCache memoryCache
        )
    {
        _documentExporterManager = documentExporterManager;
        _memoryCache = memoryCache;
    }

    [HttpGet("/List")]
    public async Task<IActionResult> ExportBucket([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
    {
        pageNumber=pageNumber<1?1:pageNumber;
        pageSize=pageSize<1?10:pageSize;
        _memoryCache.TryGetValue(MemoryCacheKey, out List<ExportBucketCollection> list);
        if (list == null || !list.Any())
        {
            var response=await _documentExporterManager.GetExportBucket();
            if (response==null)
            {
                return Ok(new List<ExportBucketCollection>());
            }
            list=response;
        }
        var  cacheResult = list.OrderByDescending(o => o.LastModified).ToList();
        var paginatedResult = cacheResult
            .Skip((pageNumber - 1) * pageSize)
            .Take(pageSize)
            .ToList();
        _memoryCache.Set(MemoryCacheKey,list,TimeSpan.FromMinutes(5));
        return Ok(paginatedResult);
    }
    [HttpGet("/Download")]
    public async Task<IActionResult> DownloadFile([FromQuery]string objectKey)
    {
        var result = await _documentExporterManager.DownloadFile(objectKey);
        return File(result, "application/octet-stream");
    }
}