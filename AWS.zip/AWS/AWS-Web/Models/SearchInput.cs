namespace AWS_Web.Models;

public class SearchInput
{
    public int SkipCount { get; set; } = 0;
    public int MaxResultCount { get; set; } = 10;
}