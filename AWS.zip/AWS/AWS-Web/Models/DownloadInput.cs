namespace AWS_Web.Models;

public class DownloadInput
{
    public string ObjectKey { get; set; }
}