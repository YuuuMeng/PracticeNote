namespace AWS_Model;

public class ExportBucketResult
{
    public List<ExportBucketCollection> ExportBucketCollection;
}
public record ExportBucketCollection
{
    public string Key { get;set; }
    public string FileName { get; set; }
    public Owner Owner { get;set; }
    public DateTime? LastModified { get;set; }
    public long Size { get;set; }
}

public record Owner
{
    public string DisplayName { get; set; }
    public string Id { get; set; }
}